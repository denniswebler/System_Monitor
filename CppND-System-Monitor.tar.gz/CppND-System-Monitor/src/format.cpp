#include <string>

#include "format.h"

using std::string;

// INPUT: seconds
// OUTPUT: HH:MM:SS
string Format::ElapsedTime(long s) {
  string timeformat = "00:00:00";
  long calc = 0;
  if (s > 0) {
    // hh
    calc = s / 3600;
    timeformat = TimeToString(calc) + ":";
    // mm
    calc = (s / 60) % 60;
    timeformat += TimeToString(calc) + ":";
    // ss
    calc = s % 60;
    timeformat += TimeToString(calc);
  }

  return timeformat;
}

// if cal < 10 return string
std::string Format::TimeToString(long t) {
  if (t < 10)
    return "0" + std::to_string(t);
  else
    return std::to_string(t);
}